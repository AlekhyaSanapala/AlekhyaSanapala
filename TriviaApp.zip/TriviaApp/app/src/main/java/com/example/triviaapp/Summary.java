package com.example.triviaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Summary extends AppCompatActivity {

    TextView nametv,cricetertv,colorstv;
    Button finishbutton,historybutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        nametv = findViewById(R.id.nametv);
        cricetertv = findViewById(R.id.cricetertv);
        colorstv = findViewById(R.id.colorstv);

        finishbutton = findViewById(R.id.finishbutton);
        historybutton = findViewById(R.id.historybutton);

        Bundle extras = getIntent().getExtras();
        String userName="",cricketer="",colors="";

        if (extras != null) {
            userName = extras.getString("uname");
            cricketer = extras.getString("cricketer");
            colors = extras.getString("colors");
            userName = "\""+userName+"\"";
        }

        nametv.setText("Hello "+userName+" :,");
     //   System.out.println("\"userName\"");
        cricetertv.setText(cricketer);
        colorstv.setText(colors);

        finishbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Summary.this,Name.class);
                startActivity(intent);
            }
        });

        historybutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Summary.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    public void onBackPressed() {
        startActivity(new Intent(Summary.this, FlagColours.class));
    }
}