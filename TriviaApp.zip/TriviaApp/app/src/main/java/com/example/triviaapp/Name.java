package com.example.triviaapp;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Name  extends AppCompatActivity {

    EditText username;
    Button loginButton;

    public static String uname="";

    public static SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name);

        username = findViewById(R.id.username);
        loginButton = findViewById(R.id.loginButton);

        db = openOrCreateDatabase("TriviaDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE  IF NOT EXISTS userdata (name varchar ,cricketer varchar,colors varchar,date varchar,time varchar)");  ;

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean valid = true;

                if (username.getText().toString().length()==0){
                    valid = false;
                    Toast.makeText(Name.this, "Please enter user name", Toast.LENGTH_SHORT).show();
                }

                if (valid){

                    uname = username.getText().toString();
                    Intent intent = new Intent(Name.this,Cricketer.class);
                    startActivity(intent);
                }
            }
        });

    }
}
