package com.example.triviaapp;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class FlagColours  extends AppCompatActivity {

    Button nextbutton;
    String colors="";
    RecyclerView clrsRecyclerView;
    ArrayList<String> colorsList = new ArrayList<>();
    ArrayList<Boolean> checkList = new ArrayList<>();
    int val =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flag_colours);

        nextbutton = findViewById(R.id.nextbutton);
        clrsRecyclerView = findViewById(R.id.clrsRecyclerView);


        addDataToList();
        ColorsAdapter colorsAdapter = new ColorsAdapter(FlagColours.this,colorsList,checkList);
        clrsRecyclerView.setLayoutManager(new LinearLayoutManager(FlagColours.this));
        clrsRecyclerView.setHasFixedSize(true);
        clrsRecyclerView.setAdapter(colorsAdapter);



        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean valid = true;

                colors = getColors();

                if (colors.length()==0){
                    valid = false;
                    Toast.makeText(FlagColours.this, "Please select colours", Toast.LENGTH_SHORT).show();
                }
                else if (val<=1){
                    valid = false;
                    Toast.makeText(FlagColours.this, "Please select colours more than 1", Toast.LENGTH_SHORT).show();
                }
                if (valid){

                    insertDataIntoDB();
                    Intent intent = new Intent(FlagColours.this,Summary.class);
                    intent.putExtra("uname",Name.uname);
                    intent.putExtra("cricketer",Cricketer.cricketer);
                    intent.putExtra("colors",colors);
                    startActivity(intent);
                }
            }
        });

    }

    private void insertDataIntoDB() {

        Date c = Calendar.getInstance().getTime();
        System.out.println("Current time => " + c);
        SimpleDateFormat df = new SimpleDateFormat("dd MMM", Locale.getDefault());
        SimpleDateFormat time = new SimpleDateFormat("hh:mm a");

        try{
            ContentValues cv = new ContentValues();
            cv.put("name",Name.uname);
            cv.put("cricketer",Cricketer.cricketer);
            cv.put("colors",colors);
            cv.put("date",df.format(c));
            cv.put("time",time.format(c));

            Name.db.insert("userdata",null,cv);

        }catch(Exception e){
e.printStackTrace();
        }



    }

    private String getColors() {
        val =0;
        StringBuilder stringBuilder = new StringBuilder();
        if (checkList.size()>0){

            for(int i=0;i<checkList.size();i++){

                if (checkList.get(i)){
                    val++;
                    String a[] = colorsList.get(i).split(" ");
                    stringBuilder.append(a[1]).append(",");
                }
            }
            if(stringBuilder.length()>0 ){
                stringBuilder.deleteCharAt(stringBuilder.length()-1);
            }
        }
        return stringBuilder.toString();
    }

    private void addDataToList() {
        colorsList = new ArrayList<>();
        checkList  = new ArrayList<>();

        colorsList.add("A) White");
        colorsList.add("B) Yellow");
        colorsList.add("C) Orange");
        colorsList.add("D) Green");

        checkList.add(false);
        checkList.add(false);
        checkList.add(false);
        checkList.add(false);
    }

    public void onBackPressed() {
        startActivity(new Intent(FlagColours.this, Cricketer.class));
    }
}