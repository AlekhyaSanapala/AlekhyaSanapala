package com.example.triviaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Cricketer  extends AppCompatActivity {

    RadioGroup cricketers_radiodgroup;
    Button nextbutton;
    public static String cricketer="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cricketer);

        cricketers_radiodgroup = findViewById(R.id.cricketers_radiodgroup);
        nextbutton = findViewById(R.id.nextbutton);

        cricketers_radiodgroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                if (checkedId==R.id.sachin){
                    cricketer  = "Sachin Tendulkar";
                }
                else  if (checkedId==R.id.virat){
                    cricketer  = "Virat Kolli";
                }
                else if (checkedId==R.id.gilchrist){
                    cricketer  = "Adam Gilchirst";
                }
                else  if (checkedId==R.id.kallis){
                    cricketer  = "Jacques Kallis";
                }
            }
        });

        nextbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean valid = true;

                if (cricketer.length()==0){
                    valid = false;
                    Toast.makeText(Cricketer.this, "Please select cricketer", Toast.LENGTH_SHORT).show();
                }

                if (valid){
                    Intent intent = new Intent(Cricketer.this,FlagColours.class);
                    intent.putExtra("cricketer",cricketer);
                    startActivity(intent);
                }
            }
        });
    }

    public void onBackPressed() {
        finish();
        startActivity(new Intent(Cricketer.this, Name.class));
    }
}