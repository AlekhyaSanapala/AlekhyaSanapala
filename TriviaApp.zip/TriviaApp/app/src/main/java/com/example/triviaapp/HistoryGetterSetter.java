package com.example.triviaapp;

public class HistoryGetterSetter {

    public HistoryGetterSetter() {
    }

    private String name;
    private String cricketer;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCricketer() {
        return cricketer;
    }

    public void setCricketer(String cricketer) {
        this.cricketer = cricketer;
    }

    public String getColors() {
        return colors;
    }

    public void setColors(String colors) {
        this.colors = colors;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    private String colors;
    private String date;
    private String time;
}
