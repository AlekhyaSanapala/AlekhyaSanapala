package com.example.triviaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView dataRecyclerView;
    Button startbutton;
    ArrayList<HistoryGetterSetter> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startbutton = findViewById(R.id.startbutton);
        dataRecyclerView = findViewById(R.id.dataRecyclerView);


        addDataToList();



        HistoryAdapter historyAdapter = new HistoryAdapter(MainActivity.this,list);
        dataRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        dataRecyclerView.setHasFixedSize(true);
        dataRecyclerView.setAdapter(historyAdapter);

        startbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Name.class);
                startActivity(intent);
            }
        });

    }

    private void addDataToList() {
        String select_sql = "Select * from userdata";
        Cursor c = Name.db.rawQuery(select_sql,null);
        c.moveToFirst();
        if (c.getCount()>0){

            list = new ArrayList<>();
            for (int i=0;i<c.getCount();i++){
                HistoryGetterSetter history = new HistoryGetterSetter();

                history.setName(c.getString(0));
                history.setCricketer(c.getString(1));
                history.setColors(c.getString(2));
                history.setDate(c.getString(3));
                history.setTime(c.getString(4));

                c.moveToNext();

                list.add(history);
            }
        }
    }
}