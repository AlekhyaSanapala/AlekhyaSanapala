package com.example.triviaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    Context context;
    ArrayList<HistoryGetterSetter> list = new ArrayList<>();

    public HistoryAdapter(MainActivity mainActivity, ArrayList<HistoryGetterSetter> list) {
        this.context = mainActivity;
        this.list = list;

    }

    @NonNull
    @Override
    public HistoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_adapter,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.ViewHolder holder, int position) {

        holder.timetv.setText("GAME "+position+" : "+list.get(position).getDate() + " "+ list.get(position).getTime());
        holder.nametv.setText(list.get(position).getName());
        holder.cricetertv.setText(list.get(position).getCricketer());
        holder.colourtv.setText(list.get(position).getColors());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView timetv,nametv,colourtv,cricetertv;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            timetv = itemView.findViewById(R.id.timetv);
            nametv = itemView.findViewById(R.id.nametv);
            colourtv = itemView.findViewById(R.id.colorstv);
            cricetertv = itemView.findViewById(R.id.cricetertv);



        }
    }
}
