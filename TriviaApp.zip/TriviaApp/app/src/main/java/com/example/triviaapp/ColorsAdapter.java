package com.example.triviaapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ColorsAdapter extends RecyclerView.Adapter<ColorsAdapter.ViewHolder>{

    Context context;
    ArrayList<String> colorsList = new ArrayList<>();
    public static ArrayList<Boolean> checkList = new ArrayList<>();

    public ColorsAdapter(FlagColours flagColours, ArrayList<String> colorsList, ArrayList<Boolean> checkList) {
        this.context=flagColours;
        this.colorsList=colorsList;
        this.checkList=checkList;

    }

    @NonNull
    @Override
    public ColorsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.clrs_adapter,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ColorsAdapter.ViewHolder holder, int position) {

        holder.colourtv.setText(colorsList.get(position));
    }

    @Override
    public int getItemCount() {
        return colorsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView colourtv;
        CheckBox colourcb;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            colourtv = itemView.findViewById(R.id.colourtv);
            colourcb = itemView.findViewById(R.id.colourcb);

            colourcb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    int position = getAdapterPosition();

                    if (b){
                        checkList.set(position,true);
                    }
                    else{
                        checkList.set(position,false);
                    }
                }
            });

        }
    }
}
